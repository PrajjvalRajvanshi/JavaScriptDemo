function validateLoginForm(){
	if(LoginForm.associateId.value==""){
		alert("Enter AssociateId");
		return false;
	}
	else if(LoginForm.password.value==""){
		alert("Enter Password");
		return false;
	}
}

function validateRegisterationFrm(e){
	if(registerForm.firstName.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter first name");
		return false;
	}
	else if(registerForm.lastName.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter last name");
		return false;
	}
	else if(registerForm.emailId.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter emailId");
		return false;
	}
	else if(registerForm.department.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter department");
		return false;
	}
	
	else if(registerForm.panCard.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter panCard");
		return false;
	}
	else if(registerForm.yearlyInvestmentUnder80c.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter yearlyInvestmentUnder80c");
		return false;
	}else if(registerForm.basicSalary.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter basic Salary");
		return false;
	}
	else if(registerForm.bankName.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter bankName");
		return false;
	}
	else if(registerForm.accountNumber.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter accountNumber");
		return false;
	}
	else if(registerForm.ifscCode.value==""){
		e.preventDefault();
		console.log(e);
		alert("Enter ifscCode");
		return false;
	}
	
}

function validatePassword() {
	if(changePasswordForm.password.value.length>=6){
		if(changePasswordForm.password.value.search(/[0-9]/)!=-1  &&  changePasswordForm.password.value.search(/[A-Z]/)!=-1 && 
				changePasswordForm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
			return true;
		}
		else{
			alert("password must contain atleast 1 number 1 uppercase letter and 1 special character");
			return false;
		}
	}
	else{
		alert("minimum of 6 characters");
		return false;
	}
}

function checkSame() {
	if(changePasswordForm.password.value != changePasswordForm.confirmPassword.value){
		alert("Password and Confirm password did not match");
		return false;
	}
}