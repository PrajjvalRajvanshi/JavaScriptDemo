function sayHello(){
	document.getElementById("msg").innerHTML="<font size='14' >Hello</font>";
	console.log("Hello console");
}

function sayHello2() {
	alert("Danger do not!!!!!");
}