package com.cg.project.beans;

public class Associate {
private int associateId;
private String password,repeatpassword;
public String getRepeatpassword() {
	return repeatpassword;
}
public void setRepeatpassword(String repeatpassword) {
	this.repeatpassword = repeatpassword;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getPanCard() {
	return panCard;
}
public void setPanCard(String panCard) {
	this.panCard = panCard;
}
public int getYearlyInvestmentUnder80c() {
	return yearlyInvestmentUnder80c;
}
public void setYearlyInvestmentUnder80c(int yearlyInvestmentUnder80c) {
	this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
}
public int getBasicSalary() {
	return basicSalary;
}
public void setBasicSalary(int basicSalary) {
	this.basicSalary = basicSalary;
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public Associate( String password, String repeatpassword, String firstName, String lastName,
		String emailId, String department, String designation, String panCard, int yearlyInvestmentUnder80c,
		int basicSalary, int accountNumber) {
	super();
	this.password = password;
	this.repeatpassword = repeatpassword;
	this.firstName = firstName;
	this.lastName = lastName;
	this.emailId = emailId;
	this.department = department;
	this.designation = designation;
	this.panCard = panCard;
	this.yearlyInvestmentUnder80c = yearlyInvestmentUnder80c;
	this.basicSalary = basicSalary;
	this.accountNumber = accountNumber;
}
private String firstName,lastName,emailId,department,designation,panCard;
private int yearlyInvestmentUnder80c,basicSalary,accountNumber;

public Associate(int associateId, String password) {
	super();
	this.associateId = associateId;
	this.password = password;
}
public Associate() {
	super();
}
public int getAssociateId() {
	return associateId;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + accountNumber;
	result = prime * result + associateId;
	result = prime * result + basicSalary;
	result = prime * result + ((department == null) ? 0 : department.hashCode());
	result = prime * result + ((designation == null) ? 0 : designation.hashCode());
	result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + ((panCard == null) ? 0 : panCard.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	result = prime * result + ((repeatpassword == null) ? 0 : repeatpassword.hashCode());
	result = prime * result + yearlyInvestmentUnder80c;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Associate other = (Associate) obj;
	if (accountNumber != other.accountNumber)
		return false;
	if (associateId != other.associateId)
		return false;
	if (basicSalary != other.basicSalary)
		return false;
	if (department == null) {
		if (other.department != null)
			return false;
	} else if (!department.equals(other.department))
		return false;
	if (designation == null) {
		if (other.designation != null)
			return false;
	} else if (!designation.equals(other.designation))
		return false;
	if (emailId == null) {
		if (other.emailId != null)
			return false;
	} else if (!emailId.equals(other.emailId))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (panCard == null) {
		if (other.panCard != null)
			return false;
	} else if (!panCard.equals(other.panCard))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	if (repeatpassword == null) {
		if (other.repeatpassword != null)
			return false;
	} else if (!repeatpassword.equals(other.repeatpassword))
		return false;
	if (yearlyInvestmentUnder80c != other.yearlyInvestmentUnder80c)
		return false;
	return true;
}
public void setAssociateId(int associateId) {
	this.associateId = associateId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
}
